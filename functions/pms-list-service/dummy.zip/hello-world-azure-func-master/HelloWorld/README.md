####
A simple Azure Function app based on HTTP Trigger.
